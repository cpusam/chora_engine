#ifndef TEXTURE_HPP
#define TEXTURE_HPP

#include "Chora.hpp"


class Texture{
	
	Texturer *x;
	
	SDL_Point pos;
	
	
	
	public:
		Texture();
};

#endif /* TEXTURE_HPP */ 
