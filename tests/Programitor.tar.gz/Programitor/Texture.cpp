#include "texture.hpp"


Texture::Texture()
{
	
}


